#!/bin/bash
# 快捷检查脚本 - 指向 scripts/utils/check_startup.sh
exec bash "$(dirname "$0")/scripts/utils/check_startup.sh" "$@"

