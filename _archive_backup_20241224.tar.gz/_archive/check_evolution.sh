#!/bin/bash
# 快捷检查脚本 - 指向 scripts/utils/check_evolution.sh
exec bash "$(dirname "$0")/scripts/utils/check_evolution.sh" "$@"

